﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ChatProject.ChatItems
{
    public partial class incomming : UserControl
    {
        private const int MaxBubbleWidth = 250;
        private const int PaddingHorizontal = 10;
        private const int PaddingVertical = 6;

        public incomming()
        {
            InitializeComponent();

            richTextBox1.BorderStyle = BorderStyle.None;
            richTextBox1.BackColor = Color.White; // Sade beyaz arka plan
            richTextBox1.ReadOnly = true;
            richTextBox1.Font = new Font("Segoe UI", 10F);
            richTextBox1.ForeColor = Color.Black;
            richTextBox1.Margin = new Padding(0);
            richTextBox1.ScrollBars = RichTextBoxScrollBars.None;

            MakePictureBoxRound(pictureBox2);

            this.Resize += (s, e) => AdjustBubbleSize();
            this.Load += (s, e) => AdjustBubbleSize();
        }

        public string Message
        {
            get => richTextBox1.Text;
            set
            {
                richTextBox1.Text = value;

                richTextBox1.SelectionStart = 0;
                richTextBox1.SelectionLength = richTextBox1.Text.Length;
                richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
                richTextBox1.SelectionLength = 0;

                AdjustBubbleSize();
            }
        }

        public Image Avatar
        {
            get => pictureBox2.Image;
            set => pictureBox2.Image = value;
        }

        private void AdjustBubbleSize()
        {
            using (Graphics g = richTextBox1.CreateGraphics())
            {
                SizeF textSize = g.MeasureString(richTextBox1.Text, richTextBox1.Font, MaxBubbleWidth);

                int newWidth = (int)Math.Ceiling(textSize.Width) + PaddingHorizontal * 2;
                int newHeight = (int)Math.Ceiling(textSize.Height) + PaddingVertical * 2;

                if (newWidth > MaxBubbleWidth)
                    newWidth = MaxBubbleWidth;

                richTextBox1.Width = newWidth;
                richTextBox1.Height = newHeight;

                pictureBox2.Location = new Point(10, 10);

                int bubbleX = pictureBox2.Right + 10;
                int bubbleY = pictureBox2.Top + (pictureBox2.Height / 2) - (newHeight / 2);
                if (bubbleY < 10) bubbleY = 10;

                richTextBox1.Location = new Point(bubbleX, bubbleY);

                MakeRichTextBoxRound(richTextBox1);

                this.Height = Math.Max(pictureBox2.Bottom, richTextBox1.Bottom) + 10;
            }
        }

        private void MakePictureBoxRound(PictureBox picBox)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(0, 0, picBox.Width, picBox.Height);
            picBox.Region = new Region(path);
        }

        private void MakeRichTextBoxRound(RichTextBox rtb, int radius = 20)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(rtb.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(rtb.Width - radius, rtb.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, rtb.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();
            rtb.Region = new Region(path);
        }
    }
}
