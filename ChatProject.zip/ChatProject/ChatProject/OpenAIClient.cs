﻿using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json; // JSON işlemleri için kütüphane

namespace ChatProject
{
    public class OpenAIClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;

        public OpenAIClient(string apiKey)
        {
            _apiKey = apiKey;
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");  // API key'i header'a ekliyoruz
        }

        // OpenAI API'sine istek gönderip yanıt alacağımız fonksiyon
        public async Task<string> GetResponseFromOpenAI(string userMessage)
        {
            var requestContent = new
            {
                model = "gpt-3.5-turbo",  // GPT modelini seçiyoruz
                messages = new[]
                {
                    new { role = "user", content = userMessage }
                },
                temperature = 0.7  // Yanıtın ne kadar yaratıcı olacağını belirler
            };

            string requestBody = JsonConvert.SerializeObject(requestContent); // Json'a dönüştürme
            StringContent content = new StringContent(requestBody, Encoding.UTF8, "application/json");

            try
            {
                // OpenAI API'ye POST isteği gönderiyoruz
                HttpResponseMessage response = await _httpClient.PostAsync("https://api.openai.com/v1/chat/completions", content);

                if (response.IsSuccessStatusCode)
                {
                    // Başarılı ise, dönen cevabı alıyoruz
                    string responseBody = await response.Content.ReadAsStringAsync();
                    dynamic jsonResponse = JsonConvert.DeserializeObject(responseBody);

                    // API'den gelen cevabı döndür
                    return jsonResponse.choices[0].message.content.ToString();
                }
                else
                {
                    return "Bir hata oluştu. Lütfen tekrar deneyin.";
                }
            }
            catch (Exception ex)
            {
                return "Bir hata oluştu: " + ex.Message;
            }
        }
    }
}
