using OpenAI_API;
using OpenAI_API.Chat;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ChatProject
{
    public partial class Form1 : Form
    {
        private OpenAIAPI _openAIClient;

        // Form sürükleme için değişkenler
        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        public Form1()
        {
            InitializeComponent();

            // Form başlıksız yap
            this.FormBorderStyle = FormBorderStyle.None;

            // panel1 Mouse eventlerini ayarla (panel1'i sürükleme alanı olarak kullanacağız)
            panel1.MouseDown += panel1_MouseDown;
            panel1.MouseMove += panel1_MouseMove;
            panel1.MouseUp += panel1_MouseUp;

            _openAIClient = new OpenAIAPI("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"); // OpenAIAPI sınıfı kullanılıyor
        }

        // panel1 mouse down - sürüklemeye başla
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        // panel1 mouse move - sürükle
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point diff = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(diff));
            }
        }

        // panel1 mouse up - sürüklemeyi durdur
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void kapat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            Panel separatorPanel = new Panel();
            separatorPanel.Dock = DockStyle.Top;
            separatorPanel.Height = 2;
            separatorPanel.BackColor = Color.Gray;
            this.Controls.Add(separatorPanel);
        }

        private void gonderTusu_Click(object sender, EventArgs e)
        {
            Send();
        }

        void Send()
        {
            if (mesajKutusu.Text.Trim().Length == 0) return;

            AddOutgoing(mesajKutusu.Text);
            string userMessage = mesajKutusu.Text;
            mesajKutusu.Text = string.Empty;

            label3.Text = "Yazıyor...";
            timer1.Start();

            GetOpenAIResponseAsync(userMessage);
        }

        void AddIncomming(string message)
        {
            var bubble = new ChatItems.incomming();
            panelOrta.Controls.Add(bubble);
            bubble.BringToFront();
            bubble.Dock = DockStyle.Top;
            bubble.Message = message;
        }

        void AddOutgoing(string message)
        {
            var bubble = new ChatItems.Outgoing();
            panelOrta.Controls.Add(bubble);
            bubble.BringToFront();
            bubble.Dock = DockStyle.Top;
            bubble.Message = message;
        }

        private async void GetOpenAIResponseAsync(string userMessage)
        {
            try
            {
                var chatRequest = new ChatRequest()
                {
                    Model = "gpt-3.5-turbo",
                    Temperature = 0.7,
                    Messages = new List<ChatMessage>
                    {
                        new ChatMessage(ChatMessageRole.User, userMessage)
                    }
                };

                var result = await _openAIClient.Chat.CreateChatCompletionAsync(chatRequest);

                timer1.Stop();
                label3.Text = "Online";
                AddIncomming(result.Choices[0].Message.Content.Trim());
            }
            catch (Exception ex)
            {
                timer1.Stop();
                label3.Text = "Online";
                AddIncomming("Hata oluştu: " + ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            label3.Text = "Online";
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            AddIncomming("Merhaba, bana bir şey sor :)");
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // İsteğe bağlı
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // İsteğe bağlı
        }

        private void mesajKutusu_TextChanged(object sender, EventArgs e)
        {
            // İsteğe bağlı
        }

        private void mesajKutusu_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Send();
            }
        }

        private void panelOrta_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
