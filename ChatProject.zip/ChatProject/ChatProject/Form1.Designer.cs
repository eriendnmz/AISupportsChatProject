﻿namespace ChatProject
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            label3 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            kapat = new Button();
            panel2 = new Panel();
            gonderTusu = new Button();
            mesajKutusu = new TextBox();
            panelOrta = new Panel();
            panel3 = new Panel();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panelOrta.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(kapat);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(375, 106);
            panel1.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.ForeColor = Color.WhiteSmoke;
            label3.Location = new Point(115, 60);
            label3.Name = "label3";
            label3.Size = new Size(57, 21);
            label3.TabIndex = 4;
            label3.Text = "Online";
            label3.Click += label3_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(115, 0);
            label1.Name = "label1";
            label1.Size = new Size(198, 60);
            label1.TabIndex = 2;
            label1.Text = "OVEO\r\nMüşteri Hizmetleri\r\n";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 106);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // kapat
            // 
            kapat.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            kapat.BackgroundImage = (Image)resources.GetObject("kapat.BackgroundImage");
            kapat.BackgroundImageLayout = ImageLayout.Stretch;
            kapat.Location = new Point(348, 0);
            kapat.Name = "kapat";
            kapat.Size = new Size(27, 28);
            kapat.TabIndex = 0;
            kapat.UseVisualStyleBackColor = true;
            kapat.Click += kapat_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkGray;
            panel2.Controls.Add(gonderTusu);
            panel2.Controls.Add(mesajKutusu);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 452);
            panel2.Name = "panel2";
            panel2.Size = new Size(375, 89);
            panel2.TabIndex = 1;
            // 
            // gonderTusu
            // 
            gonderTusu.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            gonderTusu.BackgroundImage = (Image)resources.GetObject("gonderTusu.BackgroundImage");
            gonderTusu.BackgroundImageLayout = ImageLayout.Stretch;
            gonderTusu.FlatStyle = FlatStyle.Flat;
            gonderTusu.ForeColor = SystemColors.AppWorkspace;
            gonderTusu.Location = new Point(327, 19);
            gonderTusu.Name = "gonderTusu";
            gonderTusu.Size = new Size(43, 49);
            gonderTusu.TabIndex = 1;
            gonderTusu.UseVisualStyleBackColor = true;
            gonderTusu.Click += gonderTusu_Click;
            // 
            // mesajKutusu
            // 
            mesajKutusu.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mesajKutusu.Location = new Point(3, 6);
            mesajKutusu.Multiline = true;
            mesajKutusu.Name = "mesajKutusu";
            mesajKutusu.PlaceholderText = "Mesajınızı giriniz";
            mesajKutusu.Size = new Size(318, 75);
            mesajKutusu.TabIndex = 0;
            mesajKutusu.TextChanged += mesajKutusu_TextChanged;
            mesajKutusu.KeyUp += mesajKutusu_KeyUp;
            // 
            // panelOrta
            // 
            panelOrta.AutoScroll = true;
            panelOrta.BackColor = Color.DarkGray;
            panelOrta.Controls.Add(panel3);
            panelOrta.Dock = DockStyle.Fill;
            panelOrta.Location = new Point(0, 106);
            panelOrta.Name = "panelOrta";
            panelOrta.Size = new Size(375, 346);
            panelOrta.TabIndex = 2;
            panelOrta.Paint += panelOrta_Paint;
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 345);
            panel3.Name = "panel3";
            panel3.Size = new Size(375, 1);
            panel3.TabIndex = 0;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(375, 541);
            Controls.Add(panelOrta);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Shown += Form1_Shown;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panelOrta.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button kapat;
        private Label label1;
        private Label label3;
        private Panel panel2;
        private Panel panelOrta;
        private TextBox mesajKutusu;
        private Panel panel3;
        private Button gonderTusu;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Timer timer1;
        private PictureBox pictureBox1;
    }
}
