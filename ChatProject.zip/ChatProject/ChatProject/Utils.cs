﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatProject
{
    public static class Utils
    {
        public static int GetTextHeight(RichTextBox rtb)
        {
            // Eğer text boşsa, default font yüksekliği dön
            if (string.IsNullOrWhiteSpace(rtb.Text))
                return rtb.Font.Height + 10;

            Size textSize = TextRenderer.MeasureText(rtb.Text, rtb.Font, new Size(rtb.Width, int.MaxValue), TextFormatFlags.WordBreak);
            return textSize.Height;

        }
    }

}
