document.addEventListener('DOMContentLoaded', function() {
    // --- Genel Sayfa İşlevleri ---

    // Mobil Menü (Eğer varsa)
    const mobilMenu = document.querySelector('.mobil-menu'); // Bu element HTML'de yoksa null döner
    const kapatMenu = document.querySelector('.kapat-menu'); // Bu element HTML'de yoksa null döner
    const navigasyon = document.querySelector('.navigasyon');

    if (mobilMenu) {
        mobilMenu.addEventListener('click', function() {
            navigasyon.classList.add('active');
        });
    }

    if (kapatMenu) {
        kapatMenu.addEventListener('click', function() {
            navigasyon.classList.remove('active');
        });
    }

    // Sayfa Geçiş Animasyonu (Tüm sayfalarda çalışır)
    const gecis = document.querySelector('.gecis');
    if (gecis) { // Geçiş elementi varsa çalıştır
        const pageLinks = document.querySelectorAll('a[href]:not([href^="#"]):not([href^="mailto:"]):not([href^="tel:"])');
        pageLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href === window.location.href || href.startsWith('pages/login.html')) {
                    // login.html'e doğrudan yönlendirme yap, geçiş animasyonu olmasın
                    // veya aynı sayfaya tıklayınca bir şey yapma
                    return;
                }
                e.preventDefault();
                gecis.classList.add('active');
                setTimeout(() => {
                    window.location.href = href;
                }, 500);
            });
        });

        window.addEventListener('load', function() {
            setTimeout(() => {
                gecis.classList.remove('active');
            }, 100);
        });
    }


    // Slider (index.html için özel, eğer varsa)
    const kaydirlar = document.querySelectorAll('.kaydir');
    const noktalar = document.querySelectorAll('.kaydir-nokta');
    let guncelKaydir = 0;
    const kaydirAraligi = 4600;

    if (kaydirlar.length > 0 && noktalar.length > 0) { // Slider elementleri varsa çalıştır
        function gosterKaydir(n) {
            kaydirlar.forEach(k => k.classList.remove('active'));
            noktalar.forEach(n => n.classList.remove('active'));
            guncelKaydir = (n + kaydirlar.length) % kaydirlar.length;
            kaydirlar[guncelKaydir].classList.add('active');
            noktalar[guncelKaydir].classList.add('active');
        }

        function sonrakiKaydir() {
            gosterKaydir(guncelKaydir + 1);
        }

        let kaydirZamanlayici = setInterval(sonrakiKaydir, kaydirAraligi);
        noktalar.forEach((nokta, index) => {
            nokta.addEventListener('click', () => {
                clearInterval(kaydirZamanlayici);
                gosterKaydir(index);
                kaydirZamanlayici = setInterval(sonrakiKaydir, kaydirAraligi);
            });
        });
    }

    // --- Kullanıcı Giriş/Çıkış ve Dashboard İşlevleri (Sadece ilgili sayfalarda çalışır) ---

    // Kullanıcıya Özel Sayfa Girişi (login.html için özel, eğer varsa)
    const loginForm = document.getElementById('login-form');
    if (loginForm) { // login-form elementi varsa çalış
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); // Sayfanın yeniden yüklenmesini engelle

            const phone = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();

            console.log("Girilen telefon:", phone, "Şifre:", password);

            if (phone === '05309796358' && password === 'eren1234') {
                console.log("Eren kullanıcı yönlendiriliyor...");
                window.location.href = 'eren.html';
            } else if (phone === '05431667194' && password === 'caner1234') {
                console.log("Caner kullanıcı yönlendiriliyor...");
                window.location.href = 'caner.html';
            } else if (phone === '05512767197' && password === 'emirhan1234') {
                console.log("Emirhan kullanıcı yönlendiriliyor...");
                window.location.href = 'emirhan.html';
            } else if (phone === '05419617662' && password === 'harun1234') {
                console.log("Harun kullanıcı yönlendiriliyor...");
                window.location.href = 'harun.html';
            } else {
                alert('Cep telefonu veya şifre hatalı!');
            }
        });
    }

    // Logout Butonu (Dashboard sayfaları için özel, eğer varsa)
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) { // logout-btn elementi varsa çalış
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault(); // Sayfanın yeniden yüklenmesini engelle
            window.location.href = 'login.html'; // Giriş sayfasına yönlendir
        });
    }

    // Dashboard Menü ve İçerik Yönetimi (Dashboard sayfaları için özel, eğer varsa)
    const dashboardMenuLinks = document.querySelectorAll('.dashboard-menu-link');
    const dashboardTabContents = document.querySelectorAll('.dashboard-tab-content');

    if (dashboardMenuLinks.length > 0 && dashboardTabContents.length > 0) { // Dashboard elementleri varsa çalış
        dashboardMenuLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                // Logout butonu değilse varsayılan davranışı engelle
                if (this.getAttribute('id') !== 'logout-btn') {
                    e.preventDefault();

                    // Tüm bağlantılardan ve içerik bloklarından 'active' sınıfını kaldır
                    dashboardMenuLinks.forEach(l => l.classList.remove('active'));
                    dashboardTabContents.forEach(c => c.classList.remove('active'));

                    // Tıklanan bağlantıya 'active' ekle
                    this.classList.add('active');

                    // Hedef sekmeyi göster (data-tab attribute'u ile belirleniyor)
                    const tabId = this.getAttribute('data-tab');
                    if (tabId) {
                        const tabContent = document.getElementById(tabId);
                        if (tabContent) {
                            tabContent.classList.add('active');
                        }
                    } else {
                        // Eğer data-tab yoksa veya geçersizse, varsayılan olarak dashboard home gösterilir
                        document.getElementById('dashboard-home').classList.add('active');
                    }
                }
            });
        });
    }

    // --- Chatbot Aç/Kapat ve Mesaj Gönderme ---
    const chatbotBtn = document.querySelector(".chatbot-button");
    const chatbotWindow = document.querySelector(".chatbot-window");
    const closeChatBtn = document.querySelector(".close-chat");
    const sendBtn = document.querySelector(".send-message");
    const input = document.querySelector(".chatbot-input input");
    const messagesContainer = document.querySelector(".chatbot-messages");

    // API URL'sini burada tanımlayın (Web API'nizin çalıştığı URL)
    const API_URL = "https://localhost:7237/api/Chat/Ask"; // Kendi API endpoint'inizi buraya yazın

    // Chatbotu aç/kapat
    if (chatbotBtn && chatbotWindow) {
        chatbotBtn.addEventListener("click", () => {
            chatbotWindow.classList.toggle("active");
        });
    }

    if (closeChatBtn && chatbotWindow) {
        closeChatBtn.addEventListener("click", () => {
            chatbotWindow.classList.remove("active");
        });
    }

    // Mesaj gönderme (buton veya Enter ile)
    if (sendBtn && input && messagesContainer) {
        sendBtn.addEventListener("click", sendMessage);
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                sendMessage();
            }
        });
    }

    function appendMessage(content, sender = "bot") {
        if (!messagesContainer) return;
        const msgDiv = document.createElement("div");
        msgDiv.classList.add("message", sender === "user" ? "message-user" : "message-bot");
        msgDiv.textContent = content;
        messagesContainer.appendChild(msgDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Kullanıcı adını tespit etme fonksiyonu
    function getCurrentUsername() {
        // URL'den kullanıcı adını al
        const path = window.location.pathname;
        const filename = path.substring(path.lastIndexOf('/') + 1);
        
        if (filename.endsWith('.html')) {
            const username = filename.replace('.html', '');
            
            // Bilinen kullanıcı adlarını kontrol et
            const knownUsers = ['eren', 'caner', 'harun', 'emirhan'];
            
            if (knownUsers.includes(username.toLowerCase())) {
                return username.toLowerCase();
            }
        }
        
        // Alternatif olarak, sayfa içeriğinden kullanıcı adını al
        const userNameElement = document.querySelector('.user-name');
        
        if (userNameElement) {
            const fullName = userNameElement.textContent.trim();
            
            // İsim ve soyisimden ilk ismi al
            const firstName = fullName.split(' ')[0].toLowerCase();
            
            return firstName;
        }
        
        return "guest";
    }

    async function sendMessage() {
        if (!input || !messagesContainer) return;
        const userText = input.value.trim();
        if (!userText) return;
        appendMessage(userText, "user");
        input.value = "";

        try {
            // Kullanıcı adını tespit et
            const username = getCurrentUsername();
            
            // API'ye istek gönderme
            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ 
                    message: userText,
                    username: username // Kullanıcı adını ekle
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            const botReply = data.response || "Yanıt alınamadı.";
            appendMessage(botReply, "bot");
        } catch (error) {
            console.error("API Hatası:", error);
            appendMessage("Bir hata oluştu. Lütfen tekrar deneyiniz.", "bot");
        }
    }


    // --- Diğer Sayfa Özel İşlevleri ---

    // Animasyonlar (Tüm sayfalarda çalışır)
    const animasyonluOgeler = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, .slide-in-up');

    function kontrolKaydirma() {
        const tetikleyici = window.innerHeight * 0.8;
        animasyonluOgeler.forEach(oge => {
            const ogeUst = oge.getBoundingClientRect().top;
            if (ogeUst < tetikleyici) {
                oge.style.opacity = '1';
                oge.style.transform = 'translateY(0) translateX(0)';
            }
        });
    }
    window.addEventListener('scroll', kontrolKaydirma);
    kontrolKaydirma(); // Sayfa yüklendiğinde de bir kez kontrol et

    // Tarifeler Sayfası İşlevselliği (tarifeler.html için özel, eğer varsa)
    const tarifeSecenekler = document.querySelectorAll('.tarife-secenek');
    const tarifeIcerikler = document.querySelectorAll('.tarife-icerik');

    if (tarifeSecenekler.length > 0 && tarifeIcerikler.length > 0) { // Tarife elementleri varsa çalış
        tarifeSecenekler.forEach((secenek, index) => {
            secenek.addEventListener('click', () => {
                tarifeSecenekler.forEach(s => s.classList.remove('active'));
                tarifeIcerikler.forEach(i => i.classList.remove('active'));
                secenek.classList.add('active');
                tarifeIcerikler[index].classList.add('active');
            });
        });
    }

    // İletişim Formu Ad Soyad Uyarısı (İletişim formu olan sayfalar için özel, eğer varsa)
    const nameInput = document.getElementById("name");
    const nameWarning = document.getElementById("nameWarning");

    if (nameInput && nameWarning) { // İsim inputu ve uyarı elementi varsa çalış
        nameInput.addEventListener("input", function () {
            const value = nameInput.value.trim();
            const parts = value.split(/\s+/);

            const isValid = parts.length >= 2 && parts.every(part => part.length >= 2);

            if (!isValid) {
                nameWarning.style.display = "inline";
                nameInput.setCustomValidity("Ad ve soyad bilgileri ayrı ve en az 2 harfli olmalı."); // Daha açıklayıcı bir mesaj
            } else {
                nameWarning.style.display = "none";
                nameInput.setCustomValidity("");
            }
        });
    }

    // Hız Testi İşlevselliği (Hız testi olan sayfalar için özel, eğer varsa)
    const startTestButton = document.getElementById('start-test');
    const needle = document.querySelector('.speedometer .needle');
    const progressPath = document.querySelector('.speedometer .progress');
    const speedValueDisplay = document.querySelector('.speedometer .speed-value');
    const testProgressSection = document.getElementById('test-progress');
    const testStatusDisplay = document.getElementById('test-status');
    const progressBarElement = document.getElementById('progress-bar');
    const recommendationSection = document.getElementById('recommendation');
    const recommendationTextDisplay = document.getElementById('recommendation-text');

    // Tüm hız testi elementleri varsa çalıştır
    if (startTestButton && needle && progressPath && speedValueDisplay && testProgressSection &&
        testStatusDisplay && progressBarElement && recommendationSection && recommendationTextDisplay) {

        const circumference = 283;

        const testSizes = [
            { size: 1, url: 'https://speed.cloudflare.com/1mb.bin' },
            { size: 5, url: 'https://speed.cloudflare.com/5mb.bin' },
            { size: 10, url: 'https://speed.cloudflare.com/10mb.bin' },
            { size: 25, url: 'https://speed.cloudflare.com/25mb.bin' },
            { size: 100, url: 'https://speed.cloudflare.com/100mb.bin' }
        ];

        let userSpeedHistory = {
            lastSpeed: null,
            samples: [],
            averageSpeed: null,
            variance: 0
        };

        startTestButton.addEventListener('click', function() {
            startTest();
        });

        async function startTest() {
            startTestButton.disabled = true;
            startTestButton.innerHTML = 'Test Yapılıyor... <span class="loading-spinner"></span>';
            testProgressSection.style.display = 'block';
            recommendationSection.style.display = 'none';

            updateSpeedometer(0);

            const stages = [
                'Bağlantı kontrol ediliyor...',
                'Test dosyaları hazırlanıyor...',
                'İndirme başlıyor...',
                'İndirme devam ediyor...',
                'Sonuçlar hesaplanıyor...',
                'Test tamamlandı!'
            ];

            for (let i = 0; i < stages.length - 1; i++) {
                testStatusDisplay.textContent = stages[i];
                progressBarElement.style.width = `${(i+1) * 15}%`;
                const waitTime = Math.random() * 1000 + 2000;
                await new Promise(resolve => setTimeout(resolve, waitTime));
                if (i > 1) {
                    const tempSpeed = Math.random() * 30 + 10;
                    updateSpeedometer(tempSpeed);
                }
            }

            testStatusDisplay.textContent = 'İndirme testi yapılıyor...';
            progressBarElement.style.width = '85%';

            try {
                const testsToRun = Math.floor(Math.random() * 3) + 3;
                const selectedTests = testSizes.sort(() => 0.5 - Math.random()).slice(0, testsToRun);
                const testResults = [];

                for (const test of selectedTests) {
                    const speed = await measureDownloadSpeed(test);
                    testResults.push(speed);
                    updateSpeedometer(speed);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }

                const filteredResults = removeOutliers(testResults);
                const cleanTotalSpeed = filteredResults.reduce((sum, speed) => sum + speed, 0);
                const averageSpeed = filteredResults.length > 0 ?
                    cleanTotalSpeed / filteredResults.length :
                    simulateSpeedBasedOnNavigator(15, 90);

                const finalSpeed = getConsistentSpeed(averageSpeed);

                testStatusDisplay.textContent = stages[stages.length - 1];
                progressBarElement.style.width = '100%';
                updateSpeedometer(finalSpeed);
                showRecommendation(finalSpeed);

            } catch (error) {
                console.error('Test hatası:', error);
                let simulatedSpeed;
                if (userSpeedHistory.lastSpeed !== null) {
                    const variance = userSpeedHistory.lastSpeed * 0.15;
                    simulatedSpeed = userSpeedHistory.lastSpeed + (Math.random() * variance * 2 - variance);
                } else {
                    simulatedSpeed = simulateSpeedBasedOnNavigator(15, 90);
                }
                const finalSpeed = getConsistentSpeed(simulatedSpeed);
                updateSpeedometer(finalSpeed);
                testStatusDisplay.textContent = 'Test tamamlandı!';
                progressBarElement.style.width = '100%';
                showRecommendation(finalSpeed);
            }

            setTimeout(() => {
                startTestButton.disabled = false;
                startTestButton.innerHTML = 'Hız Testini Başlat';
            }, 2000);
        }

        async function measureDownloadSpeed(testFile) {
            try {
                return new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    const startTime = performance.now();
                    let loadedBytes = 0;
                    let lastProgressTime = startTime;
                    let speedSamples = [];

                    xhr.open('GET', testFile.url, true);
                    xhr.responseType = 'blob';
                    xhr.timeout = 15000;

                    xhr.onprogress = function(event) {
                        if (event.lengthComputable) {
                            const currentTime = performance.now();
                            const bytesLoaded = event.loaded - loadedBytes;
                            const timeSpent = (currentTime - lastProgressTime) / 1000;

                            if (timeSpent > 0.1) {
                                const instantSpeed = (bytesLoaded * 8) / (timeSpent * 1000000);
                                speedSamples.push(instantSpeed);
                                loadedBytes = event.loaded;
                                lastProgressTime = currentTime;
                            }
                        }
                    };

                    xhr.onload = function() {
                        if (this.status === 200) {
                            const endTime = performance.now();
                            const totalDuration = (endTime - startTime) / 1000;
                            const finalSpeed = (testFile.size * 8) / totalDuration;

                            if (speedSamples.length > 0) {
                                const filteredSamples = removeOutliers(speedSamples);
                                const avgInstantSpeed = filteredSamples.reduce((a, b) => a + b, 0) / filteredSamples.length;
                                resolve(avgInstantSpeed * 0.6 + finalSpeed * 0.4);
                            } else {
                                resolve(finalSpeed);
                            }
                        } else {
                            reject(new Error('Dosya indirme hatası: ' + this.status));
                        }
                    };

                    xhr.onerror = function() {
                        reject(new Error('Ağ hatası oluştu'));
                    };

                    xhr.ontimeout = function() {
                        reject(new Error('İndirme zaman aşımına uğradı'));
                    };

                    xhr.send();
                });
            } catch (error) {
                console.error('İndirme testi hatası:', error);
                return simulateSpeedBasedOnNavigator(15, 90);
            }
        }

        function removeOutliers(speeds) {
            if (speeds.length <= 2) return speeds;
            const mean = speeds.reduce((sum, val) => sum + val, 0) / speeds.length;
            const stdDev = Math.sqrt(
                speeds.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / speeds.length
            );
            return speeds.filter(speed => Math.abs(speed - mean) < 2 * stdDev);
        }

        function getConsistentSpeed(currentSpeed) {
            if (userSpeedHistory.lastSpeed === null) {
                userSpeedHistory.lastSpeed = currentSpeed;
                userSpeedHistory.samples.push(currentSpeed);
                userSpeedHistory.averageSpeed = currentSpeed;
                return currentSpeed;
            }
            userSpeedHistory.samples.push(currentSpeed);
            if (userSpeedHistory.samples.length > 5) {
                userSpeedHistory.samples.shift();
            }
            const newAverage = userSpeedHistory.samples.reduce((sum, val) => sum + val, 0) /
                userSpeedHistory.samples.length;
            const weightedSpeed = currentSpeed * 0.7 + userSpeedHistory.averageSpeed * 0.3;
            userSpeedHistory.lastSpeed = currentSpeed;
            userSpeedHistory.averageSpeed = weightedSpeed;
            return weightedSpeed;
        }

        function simulateSpeedBasedOnNavigator(min, max) {
            if (navigator.connection) {
                const conn = navigator.connection;
                if (conn.effectiveType === '4g') {
                    return Math.random() * 40 + 20;
                } else if (conn.effectiveType === '3g') {
                    return Math.random() * 8 + 2;
                } else if (conn.effectiveType === '2g') {
                    return Math.random() * 0.3 + 0.1;
                } else if (conn.effectiveType === 'slow-2g') {
                    return Math.random() * 0.1 + 0.05;
                }
            }
            const speedDistributions = [
                { chance: 0.10, range: [1, 5] },
                { chance: 0.20, range: [5, 15] },
                { chance: 0.40, range: [15, 50] },
                { chance: 0.20, range: [50, 100] },
                { chance: 0.10, range: [100, 200] }
            ];
            const random = Math.random();
            let cumulativeChance = 0;
            for (const dist of speedDistributions) {
                cumulativeChance += dist.chance;
                if (random <= cumulativeChance) {
                    const [distMin, distMax] = dist.range;
                    return Math.random() * (distMax - distMin) + distMin;
                }
            }
            try {
                const screenFactor = (window.screen.width * window.screen.height) / (1920 * 1080);
                const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
                const memoryFactor = navigator.deviceMemory ? navigator.deviceMemory / 8 : 1;
                const isChrome = /Chrome/.test(navigator.userAgent);
                const isSafari = /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent);
                const isFirefox = /Firefox/.test(navigator.userAgent);
                let browserFactor = 1;
                if (isChrome) browserFactor = 1.1;
                else if (isSafari) browserFactor = 1.05;
                else if (isFirefox) browserFactor = 0.95;
                let adjustedMax = max * screenFactor * memoryFactor * browserFactor;
                if (isMobile) adjustedMax *= 0.7;
                return Math.random() * (adjustedMax - min) + min;
            } catch (error) {
                return Math.random() * (max - min) + min;
            }
        }

        function updateSpeedometer(speed) {
            const maxSpeed = 100;
            const clampedSpeed = Math.min(speed, maxSpeed);
            const angle = -90 + (clampedSpeed / maxSpeed) * 180;
            needle.style.transform = `rotate(${angle}deg)`;
            speedValueDisplay.textContent = `${clampedSpeed.toFixed(2)} Mbps`;
            const progressLength = (clampedSpeed / maxSpeed) * circumference;
            progressPath.setAttribute('stroke-dasharray', `${progressLength} ${circumference - progressLength}`);
        }

        function showRecommendation(speed) {
            recommendationSection.style.display = 'block';
            let text = '';
            if (speed <=9) {
                text = 'Bağlantınız oldukça yavaş. Sadece temel internet aktiviteleri için yeterli. 10 Mbps veya daha yüksek hız öneririz.';
                recommendationSection.className = '';
            } else if (speed <= 18) {
                text = 'Bağlantınız temel internet ihtiyaçları için yeterli. Orta ve HD kalitede video izleyebilir ve internette gezinebilirsiniz. Gezinirken yüklenmelerde gecikmeler olabilir. Çoklu cihazda HD video izleyebilmek için 25 Mbps öneririz.';
                recommendationSection.className = 'yellow';
            } else if (speed <= 40) {
                text ='Bağlantınız iyi. HD ve 4K video izleyebilir ve çoğu çevrimiçi aktivite için kullanabilirsiniz. 4K videoyu aynı anda iki farklı cihazda izleyebilmek için 45-50 Mbps öneririz.';
                recommendationSection.className = 'light-green';
            } else {
                text =' Bağlantınız çok iyi! Yüksek kaliteli içerik akışı, çoklu cihaz kullanımı ve büyük dosya indirme işlemleri için idealdir.';
                recommendationSection.className = 'dark-green';
            }
            recommendationTextDisplay.textContent = text;
        }
    }

    // SSS (Sıkça Sorulan Sorular) Kısmı (Eğer varsa)
    document.querySelectorAll('.sss-soru').forEach(function (soru) {
        // Parent elementin varlığını kontrol et (bu durumda .sss-oge)
        const oge = soru.parentElement;
        if (oge && oge.classList.contains('sss-oge')) {
            soru.addEventListener('click', function () {
                const zatenAcilmisMi = oge.classList.contains('active');
                document.querySelectorAll('.sss-oge').forEach(function (el) {
                    el.classList.remove('active');
                });
                if (!zatenAcilmisMi) {
                    oge.classList.add('active');
                }
            });
        }
    });

}); // DOMContentLoaded sonu
