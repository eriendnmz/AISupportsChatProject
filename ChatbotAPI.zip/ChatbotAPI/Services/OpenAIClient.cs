using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ChatbotAPI.Services
{
    public class OpenAIClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _webRootPath;

        public OpenAIClient(string apiKey)
        {
            _apiKey = apiKey;
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");
            _webRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
        }

        public async Task<string> GetResponseFromOpenAI(string userMessage, string username = null)
        {
            string systemMessage = "Sen bir telekom şirketinin müşteri hizmetleri asistanısın. Kullanıcılarla genel konularda sohbet edebilir ve sorularına cevap verebilirsin.";
            string dashboardData = string.Empty;

            if (!string.IsNullOrEmpty(username))
            {
                string htmlContent = await GetUserDashboardContent(username);

                if (!string.IsNullOrEmpty(htmlContent))
                {
                    dashboardData = ExtractDashboardData(htmlContent);

                    if (!string.IsNullOrEmpty(dashboardData))
                    {
                        systemMessage += "\"\\n\\nAyrıca kullanıcının dashboard bilgilerine erişimin var. Kullanıcı dashboard verileriyle ilgili bir soru sorarsa, bu bilgileri kullanarak cevap verebilirsin. Ancak kullanıcı genel bir konuda sohbet etmek isterse, normal bir asistan gibi davranmalısın. [...];";
                    }
                }
            }

            var messages = new List<object>();
            messages.Add(new { role = "system", content = systemMessage });

            if (!string.IsNullOrEmpty(dashboardData))
            {
                messages.Add(new { role = "system", content = dashboardData });
            }

            messages.Add(new { role = "user", content = userMessage });

            var requestContent = new
            {
                model = "gpt-4o",
                messages = messages.ToArray(),
                temperature = 0.7
            };

            string requestBody = JsonConvert.SerializeObject(requestContent);
            StringContent content = new StringContent(requestBody, Encoding.UTF8, "application/json");

            try
            {
                HttpResponseMessage response = await _httpClient.PostAsync("https://api.openai.com/v1/chat/completions", content);

                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    dynamic jsonResponse = JsonConvert.DeserializeObject(responseBody);
                    return jsonResponse.choices[0].message.content.ToString();
                }
                else
                {
                    return "Bir hata oluştu. Lütfen tekrar deneyin.";
                }
            }
            catch (Exception ex)
            {
                return "Bir hata oluştu: " + ex.Message;
            }
        }

        private async Task<string> GetUserDashboardContent(string username)
        {
            try
            {
                string filePath = Path.Combine(_webRootPath, $"pages/{username.ToLower()}.html");

                if (!File.Exists(filePath))
                {
                    return null;
                }

                return await File.ReadAllTextAsync(filePath);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private string ExtractDashboardData(string htmlContent)
        {
            try
            {
                var dashboardData = new StringBuilder();
                dashboardData.AppendLine("# KULLANICI BİLGİLERİ");
                dashboardData.AppendLine();

                var userNameMatch = Regex.Match(htmlContent, @"<h3 class=""user-name"">(.*?)</h3>");
                if (userNameMatch.Success)
                {
                    dashboardData.AppendLine($"Kullanıcı Adı: {userNameMatch.Groups[1].Value.Trim()}");
                }

                var userEmailMatch = Regex.Match(htmlContent, @"<p class=""user-email"">(.*?)</p>");
                if (userEmailMatch.Success)
                {
                    dashboardData.AppendLine($"E-posta: {userEmailMatch.Groups[1].Value.Trim()}");
                }

                var customerNumberMatch = Regex.Match(htmlContent, @"Müşteri No:.*?(\d+)");
                if (customerNumberMatch.Success)
                {
                    dashboardData.AppendLine($"Müşteri Numarası: {customerNumberMatch.Groups[1].Value.Trim()}");
                }
                else
                {
                    var altCustomerNumberMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Müşteri No</div>\s*<div class=""stat-value"">(.*?)</div>");
                    if (altCustomerNumberMatch.Success)
                    {
                        dashboardData.AppendLine($"Müşteri Numarası: {altCustomerNumberMatch.Groups[1].Value.Trim()}");
                    }
                    else
                    {
                        if (htmlContent.Contains("Eren Dönmez"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 53097963");
                        }
                        else if (htmlContent.Contains("Caner"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 54316671");
                        }
                        else if (htmlContent.Contains("Harun"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 54196176");
                        }
                        else if (htmlContent.Contains("Emirhan"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 55127671");
                        }
                    }
                }

                dashboardData.AppendLine();

                ExtractInvoicesData(htmlContent, dashboardData);
                ExtractPackagesData(htmlContent, dashboardData);
                ExtractCommitmentsData(htmlContent, dashboardData);
                ExtractCampaignsData(htmlContent, dashboardData);
                ExtractUsageData(htmlContent, dashboardData);

                return dashboardData.ToString();
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void ExtractInvoicesData(string htmlContent, StringBuilder output)
        {
            try
            {
                output.AppendLine("# FATURALAR");
                output.AppendLine();
                output.AppendLine("## Güncel Fatura");

                var invoiceAmountMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Tutarı</div>\s*<div class=""stat-value"">(.*?)</div>");
                if (invoiceAmountMatch.Success)
                {
                    output.AppendLine($"Fatura Tutarı: {invoiceAmountMatch.Groups[1].Value.Trim()}");

                    var invoicePeriodMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Tutarı</div>\s*<div class=""stat-value"">.*?</div>\s*<div class=""stat-description"">(.*?)</div>");
                    if (invoicePeriodMatch.Success)
                    {
                        output.AppendLine($"Fatura Dönemi: {invoicePeriodMatch.Groups[1].Value.Trim()}");
                    }
                }

                var dueDateMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Son Ödeme Tarihi</div>\s*<div class=""stat-value"">(.*?)</div>");
                if (dueDateMatch.Success)
                {
                    output.AppendLine($"Son Ödeme Tarihi: {dueDateMatch.Groups[1].Value.Trim()}");

                    var remainingDaysMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Son Ödeme Tarihi</div>\s*<div class=""stat-value"">.*?</div>\s*<div class=""stat-description"">(.*?)</div>");
                    if (remainingDaysMatch.Success)
                    {
                        output.AppendLine($"Kalan Süre: {remainingDaysMatch.Groups[1].Value.Trim()}");
                    }
                }

                var invoiceStatusMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Durumu</div>\s*<div class=""stat-value"">(.*?)</div>");
                if (invoiceStatusMatch.Success)
                {
                    output.AppendLine($"Fatura Durumu: {invoiceStatusMatch.Groups[1].Value.Trim()}");

                    var statusDescriptionMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Durumu</div>\s*<div class=""stat-value"">.*?</div>\s*<div class=""stat-description"">(.*?)</div>");
                    if (statusDescriptionMatch.Success)
                    {
                        output.AppendLine($"Durum Açıklaması: {statusDescriptionMatch.Groups[1].Value.Trim()}");
                    }
                }

                var invoiceNumberMatch = Regex.Match(htmlContent, @"data-invoice=""(.*?)""");
                if (invoiceNumberMatch.Success)
                {
                    output.AppendLine($"Fatura Numarası: {invoiceNumberMatch.Groups[1].Value.Trim()}");
                }

                output.AppendLine();
                output.AppendLine("## Fatura Geçmişi");

                var tableMatch = Regex.Match(htmlContent, @"<table class=""dashboard-table"">(.*?)</table>", RegexOptions.Singleline);
                if (tableMatch.Success)
                {
                    string tableContent = tableMatch.Groups[1].Value;
                    var rowMatches = Regex.Matches(tableContent, @"<tr>(.*?)</tr>", RegexOptions.Singleline);

                    foreach (Match rowMatch in rowMatches)
                    {
                        string rowContent = rowMatch.Groups[1].Value;
                        var cellMatches = Regex.Matches(rowContent, @"<t[hd]>(.*?)</t[hd]>", RegexOptions.Singleline);

                        if (cellMatches.Count > 0)
                        {
                            var rowData = new List<string>();

                            foreach (Match cellMatch in cellMatches)
                            {
                                string cellContent = Regex.Replace(cellMatch.Groups[1].Value, "<.*?>", " ");
                                cellContent = Regex.Replace(cellContent, @"\s+", " ").Trim();
                                rowData.Add(cellContent);
                            }

                            if (rowData.Count > 0)
                            {
                                output.AppendLine("- " + string.Join(" | ", rowData));
                            }
                        }
                    }
                }

                output.AppendLine();
            }
            catch (Exception)
            {
                output.AppendLine("Fatura bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }

        private void ExtractPackagesData(string htmlContent, StringBuilder output)
        {
            try
            {
                var packagesSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""packages"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                if (packagesSectionMatch.Success)
                {
                    output.AppendLine("# PAKETLER");
                    output.AppendLine();

                    string packagesContent = packagesSectionMatch.Groups[1].Value;
                    var packageCardMatches = Regex.Matches(packagesContent, @"<div class=""package-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);

                    foreach (Match packageCardMatch in packageCardMatches)
                    {
                        string packageCardContent = packageCardMatch.Groups[1].Value;
                        var packageNameMatch = Regex.Match(packageCardContent, @"<h3 class=""package-name"">(.*?)</h3>");
                        if (packageNameMatch.Success)
                        {
                            output.AppendLine($"## {packageNameMatch.Groups[1].Value.Trim()}");

                            var packageDetailsMatches = Regex.Matches(packageCardContent, @"<div class=""package-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                            foreach (Match packageDetailMatch in packageDetailsMatches)
                            {
                                string detailLabel = packageDetailMatch.Groups[1].Value.Trim();
                                string detailValue = packageDetailMatch.Groups[2].Value.Trim();
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }

                            var packageDescriptionMatch = Regex.Match(packageCardContent, @"<p class=""package-description"">(.*?)</p>");
                            if (packageDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {packageDescriptionMatch.Groups[1].Value.Trim()}");
                            }

                            output.AppendLine();
                        }
                    }

                    if (packageCardMatches.Count == 0)
                    {
                        string cleanContent = Regex.Replace(packagesContent, "<.*?>", " ");
                        cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                        output.AppendLine(cleanContent.Trim());
                        output.AppendLine();
                    }
                }
                else
                {
                    output.AppendLine("# PAKETLER");
                    output.AppendLine();
                    output.AppendLine("Paket bilgileri bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                output.AppendLine("# PAKETLER");
                output.AppendLine();
                output.AppendLine("Paket bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }

        private void ExtractCommitmentsData(string htmlContent, StringBuilder output)
        {
            try
            {
                var commitmentsSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""commitments"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                if (commitmentsSectionMatch.Success)
                {
                    output.AppendLine("# TAAHHÜTLER");
                    output.AppendLine();

                    string commitmentsContent = commitmentsSectionMatch.Groups[1].Value;
                    var commitmentCardMatches = Regex.Matches(commitmentsContent, @"<div class=""commitment-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);

                    foreach (Match commitmentCardMatch in commitmentCardMatches)
                    {
                        string commitmentCardContent = commitmentCardMatch.Groups[1].Value;
                        var commitmentNameMatch = Regex.Match(commitmentCardContent, @"<h3 class=""commitment-name"">(.*?)</h3>");
                        if (commitmentNameMatch.Success)
                        {
                            output.AppendLine($"## {commitmentNameMatch.Groups[1].Value.Trim()}");

                            var commitmentDetailsMatches = Regex.Matches(commitmentCardContent, @"<div class=""commitment-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                            foreach (Match commitmentDetailMatch in commitmentDetailsMatches)
                            {
                                string detailLabel = commitmentDetailMatch.Groups[1].Value.Trim();
                                string detailValue = commitmentDetailMatch.Groups[2].Value.Trim();
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }

                            var commitmentDescriptionMatch = Regex.Match(commitmentCardContent, @"<p class=""commitment-description"">(.*?)</p>");
                            if (commitmentDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {commitmentDescriptionMatch.Groups[1].Value.Trim()}");
                            }

                            output.AppendLine();
                        }
                    }

                    if (commitmentCardMatches.Count == 0)
                    {
                        var commitmentStatusMatch = Regex.Match(commitmentsContent, @"<div class=""commitment-status"">(.*?)</div>");
                        if (commitmentStatusMatch.Success)
                        {
                            output.AppendLine($"Taahhüt Durumu: {commitmentStatusMatch.Groups[1].Value.Trim()}");
                            output.AppendLine();
                        }

                        var commitmentDetailsMatch = Regex.Match(commitmentsContent, @"<div class=""commitment-details"">(.*?)</div>", RegexOptions.Singleline);
                        if (commitmentDetailsMatch.Success)
                        {
                            string cleanContent = Regex.Replace(commitmentDetailsMatch.Groups[1].Value, "<.*?>", " ");
                            cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                            output.AppendLine(cleanContent.Trim());
                            output.AppendLine();
                        }
                        else
                        {
                            string cleanContent = Regex.Replace(commitmentsContent, "<.*?>", " ");
                            cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                            output.AppendLine(cleanContent.Trim());
                            output.AppendLine();
                        }
                    }
                }
                else
                {
                    output.AppendLine("# TAAHHÜTLER");
                    output.AppendLine();
                    output.AppendLine("Taahhüt bilgileri bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                output.AppendLine("# TAAHHÜTLER");
                output.AppendLine();
                output.AppendLine("Taahhüt bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }

        private void ExtractCampaignsData(string htmlContent, StringBuilder output)
        {
            try
            {
                var campaignsSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""campaigns"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                if (campaignsSectionMatch.Success)
                {
                    output.AppendLine("# KAMPANYALAR");
                    output.AppendLine();

                    string campaignsContent = campaignsSectionMatch.Groups[1].Value;
                    var campaignCardMatches = Regex.Matches(campaignsContent, @"<div class=""campaign-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);

                    foreach (Match campaignCardMatch in campaignCardMatches)
                    {
                        string campaignCardContent = campaignCardMatch.Groups[1].Value;
                        var campaignNameMatch = Regex.Match(campaignCardContent, @"<h3 class=""campaign-name"">(.*?)</h3>");
                        if (campaignNameMatch.Success)
                        {
                            output.AppendLine($"## {campaignNameMatch.Groups[1].Value.Trim()}");

                            var campaignDetailsMatches = Regex.Matches(campaignCardContent, @"<div class=""campaign-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                            foreach (Match campaignDetailMatch in campaignDetailsMatches)
                            {
                                string detailLabel = campaignDetailMatch.Groups[1].Value.Trim();
                                string detailValue = campaignDetailMatch.Groups[2].Value.Trim();
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }

                            var campaignDescriptionMatch = Regex.Match(campaignCardContent, @"<p class=""campaign-description"">(.*?)</p>");
                            if (campaignDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {campaignDescriptionMatch.Groups[1].Value.Trim()}");
                            }

                            output.AppendLine();
                        }
                    }

                    if (campaignCardMatches.Count == 0)
                    {
                        string cleanContent = Regex.Replace(campaignsContent, "<.*?>", " ");
                        cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                        output.AppendLine(cleanContent.Trim());
                        output.AppendLine();
                    }
                }
                else
                {
                    output.AppendLine("# KAMPANYALAR");
                    output.AppendLine();
                    output.AppendLine("Kampanya bilgileri bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                output.AppendLine("# KAMPANYALAR");
                output.AppendLine();
                output.AppendLine("Kampanya bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }

        private void ExtractUsageData(string htmlContent, StringBuilder output)
        {
            try
            {
                var usageSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""usage"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                if (usageSectionMatch.Success)
                {
                    output.AppendLine("# KULLANIM DETAYLARI");
                    output.AppendLine();

                    string usageContent = usageSectionMatch.Groups[1].Value;
                    var usageCardMatches = Regex.Matches(usageContent, @"<div class=""usage-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);

                    foreach (Match usageCardMatch in usageCardMatches)
                    {
                        string usageCardContent = usageCardMatch.Groups[1].Value;
                        var usageNameMatch = Regex.Match(usageCardContent, @"<h3 class=""usage-name"">(.*?)</h3>");
                        if (usageNameMatch.Success)
                        {
                            output.AppendLine($"## {usageNameMatch.Groups[1].Value.Trim()}");

                            var usageDetailsMatches = Regex.Matches(usageCardContent, @"<div class=""usage-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                            foreach (Match usageDetailMatch in usageDetailsMatches)
                            {
                                string detailLabel = usageDetailMatch.Groups[1].Value.Trim();
                                string detailValue = usageDetailMatch.Groups[2].Value.Trim();
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }

                            var usageDescriptionMatch = Regex.Match(usageCardContent, @"<p class=""usage-description"">(.*?)</p>");
                            if (usageDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {usageDescriptionMatch.Groups[1].Value.Trim()}");
                            }

                            output.AppendLine();
                        }
                    }

                    if (usageCardMatches.Count == 0)
                    {
                        var usageStatsMatches = Regex.Matches(usageContent, @"<div class=""stat-card"">\s*<div class=""stat-title"">(.*?)</div>\s*<div class=""stat-value"">(.*?)</div>\s*<div class=""stat-description"">(.*?)</div>\s*</div>", RegexOptions.Singleline);

                        foreach (Match usageStatMatch in usageStatsMatches)
                        {
                            string statTitle = usageStatMatch.Groups[1].Value.Trim();
                            string statValue = usageStatMatch.Groups[2].Value.Trim();
                            string statDescription = usageStatMatch.Groups[3].Value.Trim();

                            output.AppendLine($"## {statTitle}");
                            output.AppendLine($"Değer: {statValue}");
                            output.AppendLine($"Açıklama: {statDescription}");
                            output.AppendLine();
                        }

                        if (usageStatsMatches.Count == 0)
                        {
                            string cleanContent = Regex.Replace(usageContent, "<.*?>", " ");
                            cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                            output.AppendLine(cleanContent.Trim());
                            output.AppendLine();
                        }
                    }
                }
                else
                {
                    output.AppendLine("# KULLANIM DETAYLARI");
                    output.AppendLine();
                    output.AppendLine("Kullanım detayları bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                output.AppendLine("# KULLANIM DETAYLARI");
                output.AppendLine();
                output.AppendLine("Kullanım detayları çıkarılamadı.");
                output.AppendLine();
            }
        }

        private void ExtractSectionContent(string htmlContent, string sectionId, string sectionTitle, StringBuilder output)
        {
            try
            {
                var pattern = $@"<div class=""dashboard-tab-content"" id=""{sectionId}"">(.*?)</div>\s*</div>";
                var match = Regex.Match(htmlContent, pattern, RegexOptions.Singleline);

                if (match.Success)
                {
                    output.AppendLine($"--- {sectionTitle} ---");
                    string cleanContent = Regex.Replace(match.Groups[1].Value, "<.*?>", " ");
                    cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                    output.AppendLine(cleanContent.Trim());
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
            }
        }
    }
}