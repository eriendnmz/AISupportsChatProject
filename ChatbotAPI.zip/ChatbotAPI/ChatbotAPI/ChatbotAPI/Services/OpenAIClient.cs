using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json; // JSON işlemleri için kütüphane

namespace ChatbotAPI.Services
{
    public class OpenAIClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _webRootPath;

        public OpenAIClient(string apiKey)
        {
            _apiKey = apiKey;
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");  // API key'i header'a ekliyoruz
            
            // Web kök dizinini belirle (wwwroot klasörü)
            _webRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
        }

        // OpenAI API'sine istek gönderip yanıt alacağımız fonksiyon
        public async Task<string> GetResponseFromOpenAI(string userMessage, string username = null)
        {
            // Sistem mesajını ve kullanıcı dashboard verilerini hazırla
            string systemMessage = "Sen bir telekom şirketinin müşteri hizmetleri asistanısın. Kullanıcılarla genel konularda sohbet edebilir ve sorularına cevap verebilirsin.";
            string dashboardData = string.Empty;
            
            // Eğer kullanıcı adı belirtilmişse, dashboard verilerini al
            if (!string.IsNullOrEmpty(username))
            {
                // Kullanıcı dashboard içeriğini al
                string htmlContent = await GetUserDashboardContent(username);
                
                if (!string.IsNullOrEmpty(htmlContent))
                {
                    // Dashboard verilerini çıkar
                    dashboardData = ExtractDashboardData(htmlContent);
                    
                    if (!string.IsNullOrEmpty(dashboardData))
                    {
                        // Sistem mesajını güncelle
                        systemMessage += "\"\\n\\nAyrıca kullanıcının dashboard bilgilerine erişimin var. Kullanıcı dashboard verileriyle ilgili bir soru sorarsa, bu bilgileri kullanarak cevap verebilirsin. Ancak kullanıcı genel bir konuda sohbet etmek isterse, normal bir asistan gibi davranmalısın. [...];";
                    }
                }
            }
            
            // OpenAI API isteği için mesajları hazırla
            var messages = new List<object>();
            
            // Sistem mesajını ekle
            messages.Add(new { role = "system", content = systemMessage });
            
            // Dashboard verilerini ekle (varsa)
            if (!string.IsNullOrEmpty(dashboardData))
            {
                messages.Add(new { role = "system", content = dashboardData });
            }
            
            // Kullanıcı mesajını ekle
            messages.Add(new { role = "user", content = userMessage });
            
            var requestContent = new
            {
                model = "gpt-3.5-turbo",  // GPT modelini seçiyoruz
                messages = messages.ToArray(),
                temperature = 0.7  // Yanıtın ne kadar yaratıcı olacağını belirler
            };

            string requestBody = JsonConvert.SerializeObject(requestContent); // Json'a dönüştürme
            StringContent content = new StringContent(requestBody, Encoding.UTF8, "application/json");

            try
            {
                // OpenAI API'ye POST isteği gönderiyoruz
                HttpResponseMessage response = await _httpClient.PostAsync("https://api.openai.com/v1/chat/completions", content);

                if (response.IsSuccessStatusCode)
                {
                    // Başarılı ise, dönen cevabı alıyoruz
                    string responseBody = await response.Content.ReadAsStringAsync();
                    dynamic jsonResponse = JsonConvert.DeserializeObject(responseBody);

                    // API'den gelen cevabı döndür
                    return jsonResponse.choices[0].message.content.ToString();
                }
                else
                {
                    return "Bir hata oluştu. Lütfen tekrar deneyin.";
                }
            }
            catch (Exception ex)
            {
                return "Bir hata oluştu: " + ex.Message;
            }
        }
        
        // Kullanıcı dashboard içeriğini okuma yardımcı metodu
        private async Task<string> GetUserDashboardContent(string username)
        {
            try
            {
                string filePath = Path.Combine(_webRootPath, $"pages/{username.ToLower()}.html");
                
                if (!File.Exists(filePath))
                {
                    return null;
                }
                
                return await File.ReadAllTextAsync(filePath);
            }
            catch (Exception)
            {
                return null;
            }
        }
        
        // Dashboard verilerini çıkarma yardımcı metodu
        private string ExtractDashboardData(string htmlContent)
        {
            try
            {
                var dashboardData = new StringBuilder();
                dashboardData.AppendLine("# KULLANICI BİLGİLERİ");
                dashboardData.AppendLine();
                
                // Kullanıcı adını çıkar
                var userNameMatch = Regex.Match(htmlContent, @"<h3 class=""user-name"">(.*?)</h3>");
                if (userNameMatch.Success)
                {
                    dashboardData.AppendLine($"Kullanıcı Adı: {userNameMatch.Groups[1].Value.Trim()}");
                }
                
                // Kullanıcı e-posta adresini çıkar
                var userEmailMatch = Regex.Match(htmlContent, @"<p class=""user-email"">(.*?)</p>");
                if (userEmailMatch.Success)
                {
                    dashboardData.AppendLine($"E-posta: {userEmailMatch.Groups[1].Value.Trim()}");
                }
                
                // Müşteri numarası (varsa)
                var customerNumberMatch = Regex.Match(htmlContent, @"Müşteri No:.*?(\d+)");
                if (customerNumberMatch.Success)
                {
                    dashboardData.AppendLine($"Müşteri Numarası: {customerNumberMatch.Groups[1].Value.Trim()}");
                }
                else
                {
                    // Alternatif müşteri numarası arama
                    var altCustomerNumberMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Müşteri No</div>\s*<div class=""stat-value"">(.*?)</div>");
                    if (altCustomerNumberMatch.Success)
                    {
                        dashboardData.AppendLine($"Müşteri Numarası: {altCustomerNumberMatch.Groups[1].Value.Trim()}");
                    }
                    else
                    {
                        // Eren Dönmez için varsayılan müşteri numarası
                        if (htmlContent.Contains("Eren Dönmez"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 53097963");
                        }
                        // Caner için varsayılan müşteri numarası
                        else if (htmlContent.Contains("Caner"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 54316671");
                        }
                        // Harun için varsayılan müşteri numarası
                        else if (htmlContent.Contains("Harun"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 54196176");
                        }
                        // Emirhan için varsayılan müşteri numarası
                        else if (htmlContent.Contains("Emirhan"))
                        {
                            dashboardData.AppendLine("Müşteri Numarası: 55127671");
                        }
                    }
                }
                
                dashboardData.AppendLine();
                
                // Dashboard bölümlerini çıkar
                ExtractInvoicesData(htmlContent, dashboardData);
                ExtractPackagesData(htmlContent, dashboardData);
                ExtractCommitmentsData(htmlContent, dashboardData);
                ExtractCampaignsData(htmlContent, dashboardData);
                ExtractUsageData(htmlContent, dashboardData);
                
                return dashboardData.ToString();
            }
            catch (Exception)
            {
                return null;
            }
        }
        
        // Faturalar bölümünü detaylı çıkarma
        private void ExtractInvoicesData(string htmlContent, StringBuilder output)
        {
            try
            {
                output.AppendLine("# FATURALAR");
                output.AppendLine();
                
                // Güncel fatura bilgilerini çıkar
                output.AppendLine("## Güncel Fatura");
                
                // Fatura tutarı
                var invoiceAmountMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Tutarı</div>\s*<div class=""stat-value"">(.*?)</div>");
                if (invoiceAmountMatch.Success)
                {
                    output.AppendLine($"Fatura Tutarı: {invoiceAmountMatch.Groups[1].Value.Trim()}");
                    
                    // Fatura dönemi
                    var invoicePeriodMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Tutarı</div>\s*<div class=""stat-value"">.*?</div>\s*<div class=""stat-description"">(.*?)</div>");
                    if (invoicePeriodMatch.Success)
                    {
                        output.AppendLine($"Fatura Dönemi: {invoicePeriodMatch.Groups[1].Value.Trim()}");
                    }
                }
                
                // Son ödeme tarihi
                var dueDateMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Son Ödeme Tarihi</div>\s*<div class=""stat-value"">(.*?)</div>");
                if (dueDateMatch.Success)
                {
                    output.AppendLine($"Son Ödeme Tarihi: {dueDateMatch.Groups[1].Value.Trim()}");
                    
                    // Kalan gün
                    var remainingDaysMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Son Ödeme Tarihi</div>\s*<div class=""stat-value"">.*?</div>\s*<div class=""stat-description"">(.*?)</div>");
                    if (remainingDaysMatch.Success)
                    {
                        output.AppendLine($"Kalan Süre: {remainingDaysMatch.Groups[1].Value.Trim()}");
                    }
                }
                
                // Fatura durumu
                var invoiceStatusMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Durumu</div>\s*<div class=""stat-value"">(.*?)</div>");
                if (invoiceStatusMatch.Success)
                {
                    output.AppendLine($"Fatura Durumu: {invoiceStatusMatch.Groups[1].Value.Trim()}");
                    
                    // Durum açıklaması
                    var statusDescriptionMatch = Regex.Match(htmlContent, @"<div class=""stat-title"">Fatura Durumu</div>\s*<div class=""stat-value"">.*?</div>\s*<div class=""stat-description"">(.*?)</div>");
                    if (statusDescriptionMatch.Success)
                    {
                        output.AppendLine($"Durum Açıklaması: {statusDescriptionMatch.Groups[1].Value.Trim()}");
                    }
                }
                
                // Fatura numarası
                var invoiceNumberMatch = Regex.Match(htmlContent, @"data-invoice=""(.*?)""");
                if (invoiceNumberMatch.Success)
                {
                    output.AppendLine($"Fatura Numarası: {invoiceNumberMatch.Groups[1].Value.Trim()}");
                }
                
                output.AppendLine();
                
                // Fatura geçmişi tablosunu çıkar
                output.AppendLine("## Fatura Geçmişi");
                
                // Tablo başlıklarını ve içeriğini çıkar
                var tableMatch = Regex.Match(htmlContent, @"<table class=""dashboard-table"">(.*?)</table>", RegexOptions.Singleline);
                if (tableMatch.Success)
                {
                    string tableContent = tableMatch.Groups[1].Value;
                    
                    // Tablo satırlarını çıkar
                    var rowMatches = Regex.Matches(tableContent, @"<tr>(.*?)</tr>", RegexOptions.Singleline);
                    
                    foreach (Match rowMatch in rowMatches)
                    {
                        string rowContent = rowMatch.Groups[1].Value;
                        
                        // Satır içindeki hücreleri çıkar
                        var cellMatches = Regex.Matches(rowContent, @"<t[hd]>(.*?)</t[hd]>", RegexOptions.Singleline);
                        
                        if (cellMatches.Count > 0)
                        {
                            var rowData = new List<string>();
                            
                            foreach (Match cellMatch in cellMatches)
                            {
                                // HTML etiketlerini temizle
                                string cellContent = Regex.Replace(cellMatch.Groups[1].Value, "<.*?>", " ");
                                // Fazla boşlukları temizle
                                cellContent = Regex.Replace(cellContent, @"\s+", " ").Trim();
                                
                                rowData.Add(cellContent);
                            }
                            
                            if (rowData.Count > 0)
                            {
                                output.AppendLine("- " + string.Join(" | ", rowData));
                            }
                        }
                    }
                }
                
                output.AppendLine();
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
                output.AppendLine("Fatura bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }
        
        // Paketler bölümünü detaylı çıkarma
        private void ExtractPackagesData(string htmlContent, StringBuilder output)
        {
            try
            {
                var packagesSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""packages"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                
                if (packagesSectionMatch.Success)
                {
                    output.AppendLine("# PAKETLER");
                    output.AppendLine();
                    
                    string packagesContent = packagesSectionMatch.Groups[1].Value;
                    
                    // Paket kartlarını çıkar
                    var packageCardMatches = Regex.Matches(packagesContent, @"<div class=""package-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);
                    
                    foreach (Match packageCardMatch in packageCardMatches)
                    {
                        string packageCardContent = packageCardMatch.Groups[1].Value;
                        
                        // Paket adını çıkar
                        var packageNameMatch = Regex.Match(packageCardContent, @"<h3 class=""package-name"">(.*?)</h3>");
                        if (packageNameMatch.Success)
                        {
                            output.AppendLine($"## {packageNameMatch.Groups[1].Value.Trim()}");
                            
                            // Paket detaylarını çıkar
                            var packageDetailsMatches = Regex.Matches(packageCardContent, @"<div class=""package-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                            
                            foreach (Match packageDetailMatch in packageDetailsMatches)
                            {
                                string detailLabel = packageDetailMatch.Groups[1].Value.Trim();
                                string detailValue = packageDetailMatch.Groups[2].Value.Trim();
                                
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }
                            
                            // Paket açıklamasını çıkar
                            var packageDescriptionMatch = Regex.Match(packageCardContent, @"<p class=""package-description"">(.*?)</p>");
                            if (packageDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {packageDescriptionMatch.Groups[1].Value.Trim()}");
                            }
                            
                            output.AppendLine();
                        }
                    }
                    
                    // Eğer paket kartı bulunamazsa, genel içeriği çıkar
                    if (packageCardMatches.Count == 0)
                    {
                        // HTML etiketlerini temizle
                        string cleanContent = Regex.Replace(packagesContent, "<.*?>", " ");
                        // Fazla boşlukları temizle
                        cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                        
                        output.AppendLine(cleanContent.Trim());
                        output.AppendLine();
                    }
                }
                else
                {
                    output.AppendLine("# PAKETLER");
                    output.AppendLine();
                    output.AppendLine("Paket bilgileri bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
                output.AppendLine("# PAKETLER");
                output.AppendLine();
                output.AppendLine("Paket bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }
        
        // Taahhütler bölümünü detaylı çıkarma
        private void ExtractCommitmentsData(string htmlContent, StringBuilder output)
        {
            try
            {
                var commitmentsSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""commitments"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                
                if (commitmentsSectionMatch.Success)
                {
                    output.AppendLine("# TAAHHÜTLER");
                    output.AppendLine();
                    
                    string commitmentsContent = commitmentsSectionMatch.Groups[1].Value;
                    
                    // Taahhüt kartlarını çıkar
                    var commitmentCardMatches = Regex.Matches(commitmentsContent, @"<div class=""commitment-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);
                    
                    foreach (Match commitmentCardMatch in commitmentCardMatches)
                    {
                        string commitmentCardContent = commitmentCardMatch.Groups[1].Value;
                        
                        // Taahhüt adını çıkar
                        var commitmentNameMatch = Regex.Match(commitmentCardContent, @"<h3 class=""commitment-name"">(.*?)</h3>");
                        if (commitmentNameMatch.Success)
                        {
                            output.AppendLine($"## {commitmentNameMatch.Groups[1].Value.Trim()}");
                            
                            // Taahhüt detaylarını çıkar
                            var commitmentDetailsMatches = Regex.Matches(commitmentCardContent, @"<div class=""commitment-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                            
                            foreach (Match commitmentDetailMatch in commitmentDetailsMatches)
                            {
                                string detailLabel = commitmentDetailMatch.Groups[1].Value.Trim();
                                string detailValue = commitmentDetailMatch.Groups[2].Value.Trim();
                                
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }
                            
                            // Taahhüt açıklamasını çıkar
                            var commitmentDescriptionMatch = Regex.Match(commitmentCardContent, @"<p class=""commitment-description"">(.*?)</p>");
                            if (commitmentDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {commitmentDescriptionMatch.Groups[1].Value.Trim()}");
                            }
                            
                            output.AppendLine();
                        }
                    }
                    
                    // Eğer taahhüt kartı bulunamazsa, genel içeriği çıkar
                    if (commitmentCardMatches.Count == 0)
                    {
                        // Taahhüt durumu
                        var commitmentStatusMatch = Regex.Match(commitmentsContent, @"<div class=""commitment-status"">(.*?)</div>");
                        if (commitmentStatusMatch.Success)
                        {
                            output.AppendLine($"Taahhüt Durumu: {commitmentStatusMatch.Groups[1].Value.Trim()}");
                            output.AppendLine();
                        }
                        
                        // Taahhüt detayları
                        var commitmentDetailsMatch = Regex.Match(commitmentsContent, @"<div class=""commitment-details"">(.*?)</div>", RegexOptions.Singleline);
                        if (commitmentDetailsMatch.Success)
                        {
                            // HTML etiketlerini temizle
                            string cleanContent = Regex.Replace(commitmentDetailsMatch.Groups[1].Value, "<.*?>", " ");
                            // Fazla boşlukları temizle
                            cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                            
                            output.AppendLine(cleanContent.Trim());
                            output.AppendLine();
                        }
                        else
                        {
                            // Genel içeriği çıkar
                            // HTML etiketlerini temizle
                            string cleanContent = Regex.Replace(commitmentsContent, "<.*?>", " ");
                            // Fazla boşlukları temizle
                            cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                            
                            output.AppendLine(cleanContent.Trim());
                            output.AppendLine();
                        }
                    }
                }
                else
                {
                    output.AppendLine("# TAAHHÜTLER");
                    output.AppendLine();
                    output.AppendLine("Taahhüt bilgileri bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
                output.AppendLine("# TAAHHÜTLER");
                output.AppendLine();
                output.AppendLine("Taahhüt bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }
        
        // Kampanyalar bölümünü detaylı çıkarma
        private void ExtractCampaignsData(string htmlContent, StringBuilder output)
        {
            try
            {
                var campaignsSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""campaigns"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                
                if (campaignsSectionMatch.Success)
                {
                    output.AppendLine("# KAMPANYALAR");
                    output.AppendLine();
                    
                    string campaignsContent = campaignsSectionMatch.Groups[1].Value;
                    
                    // Kampanya kartlarını çıkar
                    var campaignCardMatches = Regex.Matches(campaignsContent, @"<div class=""campaign-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);
                    
                    foreach (Match campaignCardMatch in campaignCardMatches)
                    {
                        string campaignCardContent = campaignCardMatch.Groups[1].Value;
                        
                        // Kampanya adını çıkar
                        var campaignNameMatch = Regex.Match(campaignCardContent, @"<h3 class=""campaign-name"">(.*?)</h3>");
                        if (campaignNameMatch.Success)
                        {
                            output.AppendLine($"## {campaignNameMatch.Groups[1].Value.Trim()}");
                            
                            // Kampanya detaylarını çıkar
                            var campaignDetailsMatches = Regex.Matches(campaignCardContent, @"<div class=""campaign-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                            
                            foreach (Match campaignDetailMatch in campaignDetailsMatches)
                            {
                                string detailLabel = campaignDetailMatch.Groups[1].Value.Trim();
                                string detailValue = campaignDetailMatch.Groups[2].Value.Trim();
                                
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }
                            
                            // Kampanya açıklamasını çıkar
                            var campaignDescriptionMatch = Regex.Match(campaignCardContent, @"<p class=""campaign-description"">(.*?)</p>");
                            if (campaignDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {campaignDescriptionMatch.Groups[1].Value.Trim()}");
                            }
                            
                            output.AppendLine();
                        }
                    }
                    
                    // Eğer kampanya kartı bulunamazsa, genel içeriği çıkar
                    if (campaignCardMatches.Count == 0)
                    {
                        // HTML etiketlerini temizle
                        string cleanContent = Regex.Replace(campaignsContent, "<.*?>", " ");
                        // Fazla boşlukları temizle
                        cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                        
                        output.AppendLine(cleanContent.Trim());
                        output.AppendLine();
                    }
                }
                else
                {
                    output.AppendLine("# KAMPANYALAR");
                    output.AppendLine();
                    output.AppendLine("Kampanya bilgileri bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
                output.AppendLine("# KAMPANYALAR");
                output.AppendLine();
                output.AppendLine("Kampanya bilgileri çıkarılamadı.");
                output.AppendLine();
            }
        }
        
        // Kullanım detayları bölümünü detaylı çıkarma
        private void ExtractUsageData(string htmlContent, StringBuilder output)
        {
            try
            {
                var usageSectionMatch = Regex.Match(htmlContent, @"<div class=""dashboard-tab-content"" id=""usage"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                
                if (usageSectionMatch.Success)
                {
                    output.AppendLine("# KULLANIM DETAYLARI");
                    output.AppendLine();
                    
                    string usageContent = usageSectionMatch.Groups[1].Value;
                    
                    // Kullanım kartlarını çıkar
                    var usageCardMatches = Regex.Matches(usageContent, @"<div class=""usage-card"">(.*?)</div>\s*</div>\s*</div>", RegexOptions.Singleline);
                    
                    foreach (Match usageCardMatch in usageCardMatches)
                    {
                        string usageCardContent = usageCardMatch.Groups[1].Value;
                        
                        // Kullanım adını çıkar
                        var usageNameMatch = Regex.Match(usageCardContent, @"<h3 class=""usage-name"">(.*?)</h3>");
                        if (usageNameMatch.Success)
                        {
                            output.AppendLine($"## {usageNameMatch.Groups[1].Value.Trim()}");
                            
                            // Kullanım detaylarını çıkar
                            var usageDetailsMatches = Regex.Matches(usageCardContent, @"<div class=""usage-detail"">\s*<div class=""detail-label"">(.*?)</div>\s*<div class=""detail-value"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                            
                            foreach (Match usageDetailMatch in usageDetailsMatches)
                            {
                                string detailLabel = usageDetailMatch.Groups[1].Value.Trim();
                                string detailValue = usageDetailMatch.Groups[2].Value.Trim();
                                
                                output.AppendLine($"{detailLabel}: {detailValue}");
                            }
                            
                            // Kullanım açıklamasını çıkar
                            var usageDescriptionMatch = Regex.Match(usageCardContent, @"<p class=""usage-description"">(.*?)</p>");
                            if (usageDescriptionMatch.Success)
                            {
                                output.AppendLine($"Açıklama: {usageDescriptionMatch.Groups[1].Value.Trim()}");
                            }
                            
                            output.AppendLine();
                        }
                    }
                    
                    // Eğer kullanım kartı bulunamazsa, genel içeriği çıkar
                    if (usageCardMatches.Count == 0)
                    {
                        // Kullanım istatistiklerini çıkar
                        var usageStatsMatches = Regex.Matches(usageContent, @"<div class=""stat-card"">\s*<div class=""stat-title"">(.*?)</div>\s*<div class=""stat-value"">(.*?)</div>\s*<div class=""stat-description"">(.*?)</div>\s*</div>", RegexOptions.Singleline);
                        
                        foreach (Match usageStatMatch in usageStatsMatches)
                        {
                            string statTitle = usageStatMatch.Groups[1].Value.Trim();
                            string statValue = usageStatMatch.Groups[2].Value.Trim();
                            string statDescription = usageStatMatch.Groups[3].Value.Trim();
                            
                            output.AppendLine($"## {statTitle}");
                            output.AppendLine($"Değer: {statValue}");
                            output.AppendLine($"Açıklama: {statDescription}");
                            output.AppendLine();
                        }
                        
                        // Eğer istatistik bulunamazsa, genel içeriği çıkar
                        if (usageStatsMatches.Count == 0)
                        {
                            // HTML etiketlerini temizle
                            string cleanContent = Regex.Replace(usageContent, "<.*?>", " ");
                            // Fazla boşlukları temizle
                            cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                            
                            output.AppendLine(cleanContent.Trim());
                            output.AppendLine();
                        }
                    }
                }
                else
                {
                    output.AppendLine("# KULLANIM DETAYLARI");
                    output.AppendLine();
                    output.AppendLine("Kullanım detayları bulunamadı.");
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
                output.AppendLine("# KULLANIM DETAYLARI");
                output.AppendLine();
                output.AppendLine("Kullanım detayları çıkarılamadı.");
                output.AppendLine();
            }
        }
        
        // Eski metod (artık kullanılmıyor)
        private void ExtractSectionContent(string htmlContent, string sectionId, string sectionTitle, StringBuilder output)
        {
            try
            {
                var pattern = $@"<div class=""dashboard-tab-content"" id=""{sectionId}"">(.*?)</div>\s*</div>";
                var match = Regex.Match(htmlContent, pattern, RegexOptions.Singleline);
                
                if (match.Success)
                {
                    output.AppendLine($"--- {sectionTitle} ---");
                    
                    // HTML etiketlerini temizle
                    string cleanContent = Regex.Replace(match.Groups[1].Value, "<.*?>", " ");
                    
                    // Fazla boşlukları temizle
                    cleanContent = Regex.Replace(cleanContent, @"\s+", " ");
                    
                    output.AppendLine(cleanContent.Trim());
                    output.AppendLine();
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
}
