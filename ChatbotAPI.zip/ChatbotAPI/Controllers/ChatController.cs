using ChatbotAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace ChatbotAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class ChatController : ControllerBase
    {
        private readonly OpenAIClient _openAiClient;
        
        public ChatController()
        {
           
            _openAiClient = new OpenAIClient("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");
        }
        
        [HttpPost]
        public async Task<IActionResult> Ask([FromBody] ChatRequest request)
        {
            if (string.IsNullOrEmpty(request.Message))
            {
                return BadRequest(new { response = "Mesaj boş olamaz." });
            }
            
            try
            {
                
                var answer = await _openAiClient.GetResponseFromOpenAI(request.Message, request.Username);
                return Ok(new { response = answer });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { response = $"Bir hata oluştu: {ex.Message}" });
            }
        }
    }
    
    public class ChatRequest
    {
        public string Message { get; set; }
        public string Username { get; set; }
    }
}
